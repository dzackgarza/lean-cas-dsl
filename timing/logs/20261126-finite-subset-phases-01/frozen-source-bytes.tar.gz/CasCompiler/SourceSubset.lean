module

-- DIAGNOSTIC ONLY: raw heartbeat checkpoints for the unchanged finite-subset source.
-- No heartbeat limits, resets, exception handling or semantic branches are changed.

public import CasCompiler.Surface
import CasCompiler.SourceTypeOrigin
public import CasCompiler.SourcePointOrigin

public section

namespace CasCompiler

open Lean Meta Elab Term CasCatalogue

/-- The registered power object whose object at some base is the native type `type`.
Source: Registry.Entry.PowerObjectEntry; `𝒫(X)` is the object family of the row at `X`.
Two power objects with the same native type remain distinct, so several matches are ambiguous. -/
def sourcePowerObject? (type : Expr) : SourceReadM (Option NativePowerObject) := do
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE power.lookup.start raw={(← IO.getNumHeartbeats)}"
  let selected ← SourceReadM.selection? type
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE power.domain.before raw={(← IO.getNumHeartbeats)}"
  let (native, objects) ← registeredSourceDomain type
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE power.domain.after raw={(← IO.getNumHeartbeats)}"
  if selected.isSome && objects.isEmpty then return none
  let state ← semanticState
  let mut found := #[]
  for row in state.powerObjects do
    let #[object] := state.objects.filter (·.id == row.object)
      | liftM (m := TermElabM) <| throwError "the registered power object {row.id.raw} has no unique original object family"
    let #[category] := state.categories.filter (·.id == object.category)
      | liftM (m := TermElabM) <| throwError "the registered power object {row.id.raw} has no complete original category"
    unless objects.isEmpty || objects.any (fun original => reprStr original == reprStr object) do
      continue
    discard <| checkedDeclaration object.declaration
    let family ← mkConstWithFreshMVarLevels object.declaration
    let base ← mkFreshExprMVar none
    liftM (m := IO) do
      IO.println s!"B0_FINITE_PHASE power.candidate.before row={row.id.raw} raw={(← IO.getNumHeartbeats)}"
    let applicable ← liftM (m := TermElabM) <| withoutModifyingState do
      let object ← elabAppArgs family #[] #[Arg.expr base] none false false
      isDefEq object native
    liftM (m := IO) do
      IO.println s!"B0_FINITE_PHASE power.candidate.after row={row.id.raw} applicable={applicable} raw={(← IO.getNumHeartbeats)}"
    unless applicable do continue
    liftM (m := IO) do
      IO.println s!"B0_FINITE_PHASE power.chosen.application.before row={row.id.raw} raw={(← IO.getNumHeartbeats)}"
    let candidate ← elabAppArgs family #[] #[Arg.expr base] none false false
    liftM (m := IO) do
      IO.println s!"B0_FINITE_PHASE power.chosen.application.after row={row.id.raw} raw={(← IO.getNumHeartbeats)}"
    discard <| isDefEq candidate native
    liftM (m := IO) do
      IO.println s!"B0_FINITE_PHASE power.base.before row={row.id.raw} raw={(← IO.getNumHeartbeats)}"
    let base ← if objects.isEmpty then liftM (m := MetaM) (instantiateMVars base) else do
      let application := native.consumeMData.headBeta
      unless application.getAppFn.isConstOf object.declaration do
        liftM (m := TermElabM) <| throwError "the power object lost its original declared application"
      let information ← getFunInfoNArgs application.getAppFn application.getAppNumArgs
      let originals := (application.getAppArgs.zip information.paramInfo).filterMap
        fun (argument, parameter) => if parameter.isExplicit then some argument else none
      let #[original] := originals
        | liftM (m := TermElabM) <| throwError "the power object changed its original base position"
      unless ← isDefEq base original do
        liftM (m := TermElabM) <| throwError "the power object changed its original native base"
      pure original
    if base.hasMVar || base.hasLevelMVar then
      liftM (m := TermElabM) <| throwError "the registered power object is not determined by its native type"
    liftM (m := IO) do
      IO.println s!"B0_FINITE_PHASE power.base.after row={row.id.raw} raw={(← IO.getNumHeartbeats)}"
    found := found.push ⟨row, object, category, base⟩
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE power.lookup.complete count={found.size} raw={(← IO.getNumHeartbeats)}"
  match found with
  | #[] => return none
  | #[selected] => return some selected
  | _ => liftM (m := TermElabM) <| throwSemanticAmbiguity "the native type is the object of several registered power objects"

/-- The registered power object at the base `base`: the rows whose object family accepts it. -/
def sourcePowerObjectAt (base : Expr) : SourceReadM NativePowerObject := do
  let state ← semanticState
  let mut found := #[]
  for row in state.powerObjects do
    let #[object] := state.objects.filter (·.id == row.object)
      | liftM (m := TermElabM) <| throwError "the registered power object {row.id.raw} has no unique original object family"
    let #[category] := state.categories.filter (·.id == object.category)
      | liftM (m := TermElabM) <| throwError "the registered power object {row.id.raw} has no complete original category"
    discard <| checkedDeclaration object.declaration
    let family ← mkConstWithFreshMVarLevels object.declaration
    let (parameters, _, _) ← forallMetaTelescopeReducing (← inferType family)
    let some parameter := parameters[0]?
      | liftM (m := TermElabM) <| throwError "the registered power object {row.id.raw} has no base parameter"
    if ← liftM (m := MetaM) <| withoutModifyingState
        (isDefEq (← inferType parameter) (← inferType base)) then
      found := found.push (⟨row, object, category, base⟩ : NativePowerObject)
  match found with
  | #[selected] => return selected
  | #[] => liftM (m := TermElabM) <| throwUnsupportedSource "no registered power object accepts this base object"
  | _ => liftM (m := TermElabM) <| throwSemanticAmbiguity "several registered power objects accept this base object"

/-- Apply a declaration of the power object at its base, then at the remaining arguments. -/
private def atBase (power : NativePowerObject) (declaration : Name) (arguments : Array Expr) :
    SourceReadM Expr := do
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.atBase.start declaration={declaration} raw={(← IO.getNumHeartbeats)}"
  discard <| checkedDeclaration declaration
  let function ← mkConstWithFreshMVarLevels declaration
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.atBase.apply.before declaration={declaration} raw={(← IO.getNumHeartbeats)}"
  let value ← elabRetainedSourceApplication function (#[power.base] ++ arguments)
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.atBase.apply.after declaration={declaration} raw={(← IO.getNumHeartbeats)}"
  return value

/-- The value of a global element `1 ⟶ Y` at the power object's registered point.
Source: PowerObjectEntry.point, the declaration consumers use to extract a value from a global
element. -/
def sourceGlobalValue (power : NativePowerObject) (element : Expr) (expected : Option Expr) :
    SourceReadM Expr := do
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.global.start raw={(← IO.getNumHeartbeats)}"
  discard <| checkedDeclaration power.row.point
  let point ← mkConstWithFreshMVarLevels power.row.point
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.global.function.before raw={(← IO.getNumHeartbeats)}"
  let function ← sourceSetFunction element
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.global.function.after raw={(← IO.getNumHeartbeats)}"
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.global.apply.before raw={(← IO.getNumHeartbeats)}"
  let value ← elabRetainedSourceApplication function #[point]
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.global.apply.after raw={(← IO.getNumHeartbeats)}"
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.global.point.before raw={(← IO.getNumHeartbeats)}"
  let selected ← retainSourcePoint element { value, powerObject := some power }
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.global.point.after raw={(← IO.getNumHeartbeats)}"
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.global.select.before raw={(← IO.getNumHeartbeats)}"
  let result ← SourceReadM.select selected expected
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.global.select.after raw={(← IO.getNumHeartbeats)}"
  return result

/-- The subset `{a₁, …, aₙ} ⊆ X`, through the registered subset-literal form of the power object.
The literal is the Finset of the elements, formed by the quotient map `List.toFinset` that the
literal form's normal form names; its denotation is the registered global element of `𝒫(X)`.
Source: Registry.Entry.SubsetLiteralEntry and lit.sets.finite_subsets. -/
def sourceSubsetLiteral (power : NativePowerObject) (elements : Array Expr) (expected : Expr) :
    SourceReadM Expr := do
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.literal.start elements={elements.size} raw={(← IO.getNumHeartbeats)}"
  let rows := (← semanticState).subsetLiterals.filter (·.powerObject == power.row.id)
  let #[row] := rows
    | if rows.isEmpty then
        liftM (m := TermElabM) <| throwUnsupportedSource "the selected power object has no registered subset-literal form"
      else liftM (m := TermElabM) <| throwSemanticAmbiguity "the selected power object has several subset-literal forms"
  unless row.type == ``Finset do
    liftM (m := TermElabM) <| throwUnsupportedSource m!"the subset-literal form {row.id.raw} has an unread literal type"
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.list.before raw={(← IO.getNumHeartbeats)}"
  let list ← mkListLit power.base elements.toList
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.list.after raw={(← IO.getNumHeartbeats)}"
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.equality.type.before raw={(← IO.getNumHeartbeats)}"
  let equalityType ← mkAppM ``DecidableEq #[power.base]
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.equality.type.after raw={(← IO.getNumHeartbeats)}"
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.equality.instance.before raw={(← IO.getNumHeartbeats)}"
  let equality ← match ← SourceReadM.tryInstance equalityType with
    | .some instanceValue => pure instanceValue
    | .none | .undef => liftM (m := TermElabM) <| throwFailedToSynthesize equalityType
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.equality.instance.after raw={(← IO.getNumHeartbeats)}"
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.toFinset.before raw={(← IO.getNumHeartbeats)}"
  let literal ← mkAppOptM ``List.toFinset #[some power.base, some equality, some list]
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.toFinset.after raw={(← IO.getNumHeartbeats)}"
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.denotation.before raw={(← IO.getNumHeartbeats)}"
  let element ← atBase power row.denotation #[literal]
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.denotation.after raw={(← IO.getNumHeartbeats)}"
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.global.before raw={(← IO.getNumHeartbeats)}"
  let value ← sourceGlobalValue power element (some expected)
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.global.after raw={(← IO.getNumHeartbeats)}"
  let some original ← SourceReadM.selection? value
    | liftM (m := TermElabM) <| throwError "the subset literal lost its complete original power-object point"
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.reference.before raw={(← IO.getNumHeartbeats)}"
  let selected ← sourceReferenceAt (.subset row) element value
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.reference.after raw={(← IO.getNumHeartbeats)}"
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.final.select.before raw={(← IO.getNumHeartbeats)}"
  let result ← SourceReadM.select { original with
    value
    reference := selected.reference
    originalApplication := selected.originalApplication }
  liftM (m := IO) do
    IO.println s!"B0_FINITE_PHASE subset.final.select.after raw={(← IO.getNumHeartbeats)}"
  return result

/-- A subset `A ⊆ X` used as an object is the set of its members, through the registered extent
of its power object. The global element of `𝒫(X)` at the point is the constant map with value
`A`, since the point's source is the terminal object.
Source: PowerObjectEntry.extent; the original reader's rule that a subset names its extent. -/
def sourceExtent? (judgement : NativeSourceJudgement) : SourceReadM (Option NativeSourceJudgement) := do
  if judgement.category.isSome then return none
  let selected ← SourceReadM.selection? judgement.value
  let power ← match selected with
    | some selected =>
      match selected.powerObject, selected.pointOrigin with
      | some original, some _ => pure (some original)
      | _, _ => sourcePowerObject? (← liftM (m := MetaM) <| instantiateMVars (← inferType judgement.value))
    | none => sourcePowerObject? (← liftM (m := MetaM) <| instantiateMVars (← inferType judgement.value))
  let some power := power | return none
  discard <| checkedDeclaration power.row.extent
  let extent ← mkConstWithFreshMVarLevels power.row.extent
  let element ← mkFreshExprMVar none
  discard <| elabAppArgs extent #[] #[Arg.expr power.base, Arg.expr element] none false false
  let elementType ← liftM (m := MetaM) <| instantiateMVars (← inferType element)
  let reference ← liftM (m := TermElabM) getRef
  let (global, _) ← elabSourceApplicationScoped
    (← mkConstWithFreshMVarLevels ``TypeCat.ofHom) #[reference] (some elementType)
    (sourceInstance := some SourceReadM.tryInstance) fun _ functionType => do
    let pointType ← liftM (m := MetaM) do
      let .forallE _ domain _ _ ← whnf functionType
        | throwError "the extent's native map constructor lost its function domain"
      pure domain
    let constant ← liftM (m := MetaM) <| withLocalDeclD `point pointType fun point => do
      mkLambdaFVars #[point] judgement.value
    SourceReadM.select { value := constant } (some functionType)
  let object ← elabRetainedSourceApplication extent #[power.base, global]
  let judgement ← sourceSetJudgement .object object
  let selected := (← SourceReadM.selection? judgement.value).getD { value := judgement.value }
  let value ← SourceReadM.select { selected with
    value := judgement.value
    powerObject := some power }
  return some { judgement with value }

/-- `x ∈ A` for a subset `A` of `X`: the registered membership `X × 𝒫 X → Ω` at the pair. -/
def sourceMembership (power : NativePowerObject) (element container : Expr) : SourceReadM Expr := do
  let member ← atBase power power.row.member #[]
  let function ← sourceSetFunction member
  let pair ← mkAppM ``Prod.mk #[element, container]
  let reference ← liftM (m := TermElabM) getRef
  let (value, _) ← elabSourceApplicationScoped function #[reference] none
    (sourceInstance := some SourceReadM.tryInstance) fun _ expected =>
      retainSourceConstructor pair (some expected)
  SourceReadM.select { value, powerObject := some power }

/-- `{t ∈ X | P}`: the subset that the predicate `t ↦ P : X → Ω` classifies, through the
registered transpose. `predicate` is the native function into the truth values. -/
def sourceComprehension (power : NativePowerObject) (predicate : Expr) (expected : Option Expr) :
    SourceReadM Expr := do
  let transpose ← mkConstWithFreshMVarLevels power.row.transpose
  discard <| checkedDeclaration power.row.transpose
  let classifier ← mkFreshExprMVar none
  discard <| elabAppArgs transpose #[] #[Arg.expr power.base, Arg.expr classifier] none false false
  let classifierType ← liftM (m := MetaM) <| instantiateMVars (← inferType classifier)
  let classifierValue ← elabRetainedSourceApplication (← mkConstWithFreshMVarLevels ``TypeCat.ofHom)
    #[predicate] (some classifierType)
  let element ← atBase power power.row.transpose #[classifierValue]
  sourceGlobalValue power element expected

/-- `f(X)` for a map `f : X → Y` applied to its whole domain: the image of `f` in `𝒫(Y)`, through
the registered image of the power object of `Y`. `target` is the power object at `Y`. -/
def sourceImageOf (target : NativePowerObject) (domain arrow : Expr) (expected : Option Expr) :
    SourceReadM Expr := do
  let image ← mkConstWithFreshMVarLevels target.row.image
  discard <| checkedDeclaration target.row.image
  let element ← elabRetainedSourceApplication image #[domain, target.base, arrow]
  sourceGlobalValue target element expected

/-- `{e | t ∈ X}`: the image of the whole map `t ↦ e : X → Y` in `𝒫(Y)`, through the registered
image of the power object of `Y`. `target` is the power object at `Y`. -/
def sourceImage (target : NativePowerObject) (domain function : Expr) (expected : Option Expr) :
    SourceReadM Expr := do
  let image ← mkConstWithFreshMVarLevels target.row.image
  discard <| checkedDeclaration target.row.image
  let arrow ← mkFreshExprMVar none
  discard <| elabAppArgs image #[] #[Arg.expr domain, Arg.expr target.base, Arg.expr arrow]
    none false false
  let arrowType ← liftM (m := MetaM) <| instantiateMVars (← inferType arrow)
  let arrowValue ← elabRetainedSourceApplication (← mkConstWithFreshMVarLevels ``TypeCat.ofHom)
    #[function] (some arrowType)
  sourceImageOf target domain arrowValue expected

end CasCompiler
