module

-- DIAGNOSTIC ONLY: raw heartbeat checkpoints for the unchanged finite-subset source.
-- No heartbeat limits, resets, exception handling or semantic branches are changed.

public import CasCompiler.ReadContext
public import CasCompiler.ReadSubset
public import CasCompiler.ReadAdmission
public import CasCompiler.SourceNumeral

public section

namespace CasCompiler

open Lean Meta Elab Term

namespace ReadSubsetRules

open SourceReader

def rule (context : ReadContext) : SourceReadM NativeSourceJudgement := do
  let readExpression := @ReadContext.readExpression context
  let categoryOf := context.categoryOf
  let source := context.source
  let expected := context.expected
  let admitted := admitted context
  let membership := membership context
  let boundIn := boundIn context
  match source with
  | `(cas_term| $element:cas_term ∈ $container:cas_term) => membership element container
  | `(cas_term| $element:cas_term ∉ $container:cas_term) => do
    return ⟨mkNot (← membership element container).value, none⟩
  | `(cas_term| {$elements:cas_term,*}) => do
    liftM (m := IO) do
      IO.println s!"B0_FINITE_PHASE rule.literal.start raw={(← IO.getNumHeartbeats)}"
    let expected ← match expected with
      | some expected => pure expected
      | none => do
        -- With no declared power object, the set in which the elements meet determines it
        -- (`span({u₁, u₂})` for vectors of ℚ³).
        let types ← elements.getElems.mapM fun element => do
          liftM (m := IO) do
            IO.println s!"B0_FINITE_PHASE rule.element.infer.read.before raw={(← IO.getNumHeartbeats)}"
          let value ← readExpression categoryOf element none
          liftM (m := IO) do
            IO.println s!"B0_FINITE_PHASE rule.element.infer.read.after raw={(← IO.getNumHeartbeats)}"
          inferType value.value
        liftM (m := IO) do
          IO.println s!"B0_FINITE_PHASE rule.inferred.base.before raw={(← IO.getNumHeartbeats)}"
        let some base ← sourceCommonDomain types
          | liftM (m := TermElabM) <| throwError "a source set literal requires its declared power object"
        liftM (m := IO) do
          IO.println s!"B0_FINITE_PHASE rule.inferred.base.after raw={(← IO.getNumHeartbeats)}"
        liftM (m := IO) do
          IO.println s!"B0_FINITE_PHASE rule.inferred.power.before raw={(← IO.getNumHeartbeats)}"
        let power ← sourcePowerObjectAt base
        liftM (m := IO) do
          IO.println s!"B0_FINITE_PHASE rule.inferred.power.after raw={(← IO.getNumHeartbeats)}"
        let some object := (← CasCatalogue.semanticState).objects.find? (·.id == power.row.object)
          | liftM (m := TermElabM) <| throwError "the registered power object has no object family"
        let family ← mkConstWithFreshMVarLevels object.declaration
        elabAppArgs family #[] #[Arg.expr base] none false false
    -- A literal in an admitted subobject of a power object (`𝒫_fin(X)`) is admitted there.
    let expected ← liftM (m := MetaM) <| instantiateMVars expected
    liftM (m := IO) do
      IO.println s!"B0_FINITE_PHASE rule.admission.detect.before raw={(← IO.getNumHeartbeats)}"
    let admission ← sourceAdmissionDomain? expected
    liftM (m := IO) do
      IO.println s!"B0_FINITE_PHASE rule.admission.detect.after raw={(← IO.getNumHeartbeats)}"
    if let some entry := admission then do
      liftM (m := IO) do
        IO.println s!"B0_FINITE_PHASE rule.admission.enter entry={entry.id.raw} raw={(← IO.getNumHeartbeats)}"
      let value ← admitted entry source expected
      liftM (m := IO) do
        IO.println s!"B0_FINITE_PHASE rule.admission.return entry={entry.id.raw} raw={(← IO.getNumHeartbeats)}"
      return ⟨value, none⟩
    liftM (m := IO) do
      IO.println s!"B0_FINITE_PHASE rule.power.before raw={(← IO.getNumHeartbeats)}"
    let some power ← sourcePowerObject? expected
      | liftM (m := TermElabM) <| throwError "a source set literal requires a subset of a registered power object"
    liftM (m := IO) do
      IO.println s!"B0_FINITE_PHASE rule.power.after raw={(← IO.getNumHeartbeats)}"
    -- Elements are read in the registered form of the base set (`Poly(ℤ)` for `Polynomial ℤ`).
    liftM (m := IO) do
      IO.println s!"B0_FINITE_PHASE rule.base.before raw={(← IO.getNumHeartbeats)}"
    let base ← sourceRegisteredForm power.base
    liftM (m := IO) do
      IO.println s!"B0_FINITE_PHASE rule.base.after raw={(← IO.getNumHeartbeats)}"
    let elements ← elements.getElems.mapM fun element => do
      liftM (m := IO) do
        IO.println s!"B0_FINITE_PHASE rule.element.read.before raw={(← IO.getNumHeartbeats)}"
      let value ← readExpression categoryOf element (some base)
      liftM (m := IO) do
        IO.println s!"B0_FINITE_PHASE rule.element.read.after raw={(← IO.getNumHeartbeats)}"
      return value.value
    liftM (m := IO) do
      IO.println s!"B0_FINITE_PHASE rule.literal.form.before raw={(← IO.getNumHeartbeats)}"
    let value ← sourceSubsetLiteral power elements expected
    liftM (m := IO) do
      IO.println s!"B0_FINITE_PHASE rule.literal.form.after raw={(← IO.getNumHeartbeats)}"
    return ⟨value, none⟩
  | `(cas_term| {$bound:ident ∈ $domain:cas_term | $body:cas_term}) => do
    -- Over a subset `A ⊆ X`: `{t ∈ X | t ∈ A and P}`, through `A`'s power object.
    let subset ← readExpression categoryOf domain none
    let type ← liftM (m := MetaM) <| instantiateMVars (← inferType subset.value)
    if let some power ← sourcePowerObject? type then
      return ← SourceReadM.withBinder bound.getId power.base none .default
          (fun _ judgement => pure judgement) fun parameter => do
        let predicate ← readExpression categoryOf body (some (mkSort .zero))
        let member ← sourceMembership power parameter subset.value
        let predicate ← mkLambdaFVars #[parameter] (mkAnd member predicate.value)
        return (⟨← sourceComprehension power predicate expected, none⟩ : NativeSourceJudgement)
    boundIn bound domain fun base parameter => do
      let predicate ← readExpression categoryOf body (some (mkSort .zero))
      let predicate ← mkLambdaFVars #[parameter] predicate.value
      let power ← sourcePowerObjectAt base
      return (⟨← sourceComprehension power predicate expected, none⟩ : NativeSourceJudgement)
  | `(cas_term| {$body:cas_term | $bound:ident ∈ $domain:cas_term}) =>
    boundIn bound domain fun base parameter => do
      let value ← readExpression categoryOf body none
      let target ← liftM (m := MetaM) <| instantiateMVars (← inferType value.value)
      if target.containsFVar parameter.fvarId! then
        liftM (m := TermElabM) <| throwError "the source image has a codomain that depends on its bound variable"
      let function ← mkLambdaFVars #[parameter] value.value
      let power ← sourcePowerObjectAt target
      return (⟨← sourceImage power base function expected, none⟩ : NativeSourceJudgement)
  | _ => throwReadRuleMismatch

end ReadSubsetRules

end CasCompiler
