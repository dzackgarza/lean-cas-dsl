module

-- DIAGNOSTIC ONLY: inline raw heartbeat checkpoints; no limits, resets, or semantic changes.

public import CasCompiler.ReadContext
public import CasCompiler.ReadOperation

public section

namespace CasCompiler

open Lean Meta Elab Term

namespace ReadOperationRules

open SourceReader

def rule (context : ReadContext) : SourceReadM NativeSourceJudgement := do
  let readExpression := @ReadContext.readExpression context
  let categoryOf := context.categoryOf
  let source := context.source
  let expected := context.expected
  let qualification := context.qualification
  let expectedCategory := context.expectedCategory
  let elementOperation := elementOperation context
  let action := action context
  let relation := relation context
  match source with
  | `(cas_term| $left:cas_term + $right:cas_term) => do
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE rule.addition.before raw={(← IO.getNumHeartbeats)}"
    let value ← elementOperation "+" #[left, right] #[] #[] none
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE rule.addition.after raw={(← IO.getNumHeartbeats)}"
    pure value
  | `(cas_term| $left:cas_term - $right:cas_term) => do
    -- `x - y` is `x + -y` in the selected structure (public language contract).
    -- The expansion is read once through the same registered addition and negation.
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE rule.subtraction.before raw={(← IO.getNumHeartbeats)}"
    let value ← readExpression categoryOf (← liftM (m := TermElabM) `(cas_term| $left:cas_term + (-$right:cas_term)))
      expected qualification expectedCategory
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE rule.subtraction.after raw={(← IO.getNumHeartbeats)}"
    return value
  | `(cas_term| $left:cas_term ∪ $right:cas_term) =>
    elementOperation "∪" #[left, right] #[] #[] none
  | `(cas_term| $left:cas_term ∩ $right:cas_term) =>
    elementOperation "∩" #[left, right] #[] #[] none
  | `(cas_term| $left:cas_term \ $right:cas_term) =>
    elementOperation "\\" #[left, right] #[] #[] none
  | `(cas_term| $left:cas_term △ $right:cas_term) =>
    elementOperation "△" #[left, right] #[] #[] none
  | `(cas_term| $left:cas_term ⊆ $right:cas_term) => relation "⊆" left right
  | `(cas_term| $left:cas_term ≤ $right:cas_term) => relation "≤" left right
  | `(cas_term| $left:cas_term < $right:cas_term) => relation "<" left right
  | `(cas_term| $left:cas_term · $right:cas_term) =>
    elementOperation "·" #[left, right] #[] #[] none
  | `(cas_term| $left:cas_term • $right:cas_term) => action left right
  | `(cas_term| -$operand:cas_term) => do
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE rule.negation.before raw={(← IO.getNumHeartbeats)}"
    let value ← elementOperation "-" #[operand] #[] #[] none
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE rule.negation.after raw={(← IO.getNumHeartbeats)}"
    pure value
  | `(cas_term| $operand:cas_term⁻¹) =>
    elementOperation "⁻¹" #[operand] #[] #[] none
  | _ => throwReadRuleMismatch

end ReadOperationRules

end CasCompiler
