module

-- DIAGNOSTIC ONLY: inline raw heartbeat checkpoints; no limits, resets, or semantic changes.

public import CasCompiler.ReadContext
public import CasCompiler.SourceOperation
public import CasCompiler.SourceTuple
public import CasCompiler.SourceRing
public import CasCompiler.SourceAdmission
public import CasCompiler.SourceMember
import CasCompiler.SourceCarrier

public section

namespace CasCompiler

open Lean Meta Elab Term

namespace SourceReader

/-- Reuse an already read operand at its declared operation input. The same registered
coercions and exact-domain checks as ordinary operations apply; only their own explicit
native mismatch is a rejected candidate. The source expression is never read again. -/
private def retainedOperandApplicable (reference : Syntax) (value expected : Expr) :
    SourceReadM (Except MessageData Expr) := SourceReadM.withRef reference do
  let actual ← inferType value
  liftM (m := IO) do
    IO.println s!"B0_ELEMENT_PHASE operand.retained.nativeFits.before raw={(← IO.getNumHeartbeats)}"
  let nativeFits ← withoutModifyingState (isDefEq actual expected)
  liftM (m := IO) do
    IO.println s!"B0_ELEMENT_PHASE operand.retained.nativeFits.after fits={nativeFits} raw={(← IO.getNumHeartbeats)}"
  let scope ← get
  liftM (m := IO) do
    IO.println s!"B0_ELEMENT_PHASE operand.retained.sourceFits.before raw={(← IO.getNumHeartbeats)}"
  let sourceFits ← if nativeFits then pure true else
    scope.context.withOriginalSources #[actual, expected] fun original =>
      withoutModifyingState (isDefEq original[0]! original[1]!)
  liftM (m := IO) do
    IO.println s!"B0_ELEMENT_PHASE operand.retained.sourceFits.after fits={sourceFits} raw={(← IO.getNumHeartbeats)}"
  unless sourceFits do
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE operand.retained.coercion.before raw={(← IO.getNumHeartbeats)}"
    if let some mapped ← sourceCoercion? value expected then return .ok mapped
  liftM (m := IO) do
    IO.println s!"B0_ELEMENT_PHASE operand.retained.domain.before raw={(← IO.getNumHeartbeats)}"
  match ← registeredSourceDomainsApplicable actual expected with
  | .error message => return .error message
  | .ok () => pure ()
  liftM (m := IO) do
    IO.println s!"B0_ELEMENT_PHASE operand.retained.domain.after raw={(← IO.getNumHeartbeats)}"
  unless sourceFits do
    return .error m!"the retained operand has a different declared domain"
  if nativeFits then
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE operand.retained.nativeCommit.before raw={(← IO.getNumHeartbeats)}"
    unless ← isDefEq actual expected do
      return .error m!"the retained operand has a different declared domain"
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE operand.retained.nativeCommit.after raw={(← IO.getNumHeartbeats)}"
    return .ok value
  let selected := (← SourceReadM.selection? value).getD { value }
  liftM (m := IO) do
    IO.println s!"B0_ELEMENT_PHASE operand.retained.select.before raw={(← IO.getNumHeartbeats)}"
  let value ← SourceReadM.select { selected with value } (some expected)
  liftM (m := IO) do
    IO.println s!"B0_ELEMENT_PHASE operand.retained.select.after raw={(← IO.getNumHeartbeats)}"
  return .ok value

private def elementOperationCore (context : ReadContext) :
    String → Array (TSyntax `cas_term) → Array (TSyntax `cas_term) → Array (Option Expr) → Option Expr → ExceptT MessageData SourceReadM NativeSourceJudgement :=
  let readExpression := @ReadContext.readExpression context
  let categoryOf := context.categoryOf
  let expected := context.expected
  fun (name : String) (operands : Array (TSyntax `cas_term))
      (numerals : Array (TSyntax `cas_term)) (known : Array (Option Expr))
      (domainHint : Option Expr) => do
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE reader.operation.start name={name} arity={operands.size} raw={(← IO.getNumHeartbeats)}"
    let mut retained : Array (Option Expr) := Array.replicate operands.size none
    let mut hints : Array Expr := #[]
    for operand in operands, index in [:operands.size] do
      if let some (some value) := known[index]? then
        retained := retained.set! index (some value)
        hints := hints.push (← inferType value)
        continue
      if let `(cas_term| $identifier:ident) := operand then
        if ((← liftM (m := MetaM) getLCtx).findFromUserName? identifier.getId).isSome then
          liftM (m := IO) do
            IO.println s!"B0_ELEMENT_PHASE reader.identifier.before name={name} index={index} raw={(← IO.getNumHeartbeats)}"
          let value ← readExpression categoryOf operand none
          liftM (m := IO) do
            IO.println s!"B0_ELEMENT_PHASE reader.identifier.after name={name} index={index} raw={(← IO.getNumHeartbeats)}"
          retained := retained.set! index (some value.value)
          hints := hints.push (← inferType value.value)
    let contextual ← liftM (m := MetaM) <| expected.mapM instantiateMVars
    let contextual := contextual.filter (! ·.headBeta.consumeMData.getAppFn.isMVar)
    let inputContext := contextual.filter (! ·.headBeta.consumeMData.isSort)
    -- Actual typed operands determine the input domain before the expected result.
    -- Relations land in Ω; that result must not replace their selected operand owner.
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE reader.domain.before name={name} raw={(← IO.getNumHeartbeats)}"
    let domain ← match domainHint.or (← sourceCommonDomain hints) |>.or inputContext with
      | some type => pure type
      | none => do
        let mut domain := hints[0]?
        if domain.isNone then
          for operand in operands, index in [:operands.size] do
            if let `(cas_term| $_:num) := operand then continue
            let value ← readExpression categoryOf operand none
            retained := retained.set! index (some value.value)
            hints := hints.push (← inferType value.value)
          domain ← sourceCommonDomain hints
        if let some selectedDomain := domain then pure selectedDomain
        else do
          let defaults := (← CasCatalogue.semanticState).objects.filter
            (·.notations.contains "literal.integral.domain")
          let #[entry] := defaults
            | liftM (m := TermElabM) <| CasCatalogue.throwSemanticAmbiguity "the source operation requires its scalar domain"
          discard <| checkedDeclaration entry.declaration
          mkConstWithFreshMVarLevels entry.declaration
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE reader.domain.after name={name} raw={(← IO.getNumHeartbeats)}"
    let originalOperand := retained
    let operationHints := if domainHint.isSome then #[domain] else hints
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE reader.sourceOperation.before name={name} raw={(← IO.getNumHeartbeats)}"
    let operation ← sourceOperation categoryOf name domain contextual operationHints operands.size
      (numerals.map fun numeral type => do
        return (← readExpression categoryOf numeral (some type)).value)
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE reader.sourceOperation.after name={name} raw={(← IO.getNumHeartbeats)}"
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE reader.function.before name={name} raw={(← IO.getNumHeartbeats)}"
    let function ← sourceSetFunction operation.value
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE reader.function.after name={name} raw={(← IO.getNumHeartbeats)}"
    let argument ← mkFreshExprMVar none
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE reader.argument.native.before name={name} raw={(← IO.getNumHeartbeats)}"
    discard <| elabAppArgs function #[] #[Arg.expr argument] none false false
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE reader.argument.native.after name={name} raw={(← IO.getNumHeartbeats)}"
    let cursor : IO.Ref Nat ← liftM (m := IO) (IO.mkRef 0)
    let readOperand : TSyntax `cas_term → Expr → ExceptT MessageData SourceReadM Expr := fun source type => do
      let index : Nat ← liftM (m := IO) cursor.get
      liftM (m := IO) (cursor.set (index + 1))
      liftM (m := IO) do
        IO.println s!"B0_ELEMENT_PHASE reader.operand.start name={name} index={index} raw={(← IO.getNumHeartbeats)}"
      let some transport := operation.inputTransports[index]?
        | liftM (m := TermElabM) <| throwError "the source operation lost its declared operand position"
      let read : Expr → ExceptT MessageData SourceReadM Expr := fun expected => do
        if let some (some value) := originalOperand[index]? then
          return ← ExceptT.mk <| retainedOperandApplicable source value expected
        liftM (m := IO) do
          IO.println s!"B0_ELEMENT_PHASE reader.operand.fresh.before name={name} index={index} raw={(← IO.getNumHeartbeats)}"
        let result ← ExceptT.mk <|
          context.readExpressionApplicable categoryOf source (some expected)
        liftM (m := IO) do
          IO.println s!"B0_ELEMENT_PHASE reader.operand.fresh.after name={name} index={index} raw={(← IO.getNumHeartbeats)}"
        return result.value
      let value ← if transport then do
          let some comparison := operation.comparison
            | liftM (m := TermElabM) <| throwError "the source operand lost its supplied comparison"
          let iso ← whnfR (← inferType comparison)
          let value ← read iso.getAppArgs[3]!
          let inverse ← mkAppM ``CategoryTheory.Iso.inv #[comparison]
          let inverse ← sourceSetFunction inverse
          liftM <| elabRetainedSourceApplication inverse #[value] (some type)
        else if operation.inputDomains[index]?.getD false then read domain
        else read type
      liftM (m := IO) do
        IO.println s!"B0_ELEMENT_PHASE reader.operand.slotCheck.before name={name} index={index} raw={(← IO.getNumHeartbeats)}"
      if ← withoutModifyingState (isDefEq (← inferType value) type) then return value
      -- A supplied comparison can expose its original carrier instead of this opaque
      -- native slot. Retain the actual transported operand; context capture checks its
      -- complete original type before the tuple producer consumes it.
      liftM (m := IO) do
        IO.println s!"B0_ELEMENT_PHASE reader.operand.slotCheck.false name={name} index={index} raw={(← IO.getNumHeartbeats)}"
      let selected := (← SourceReadM.selection? value).getD { value }
      liftM (m := IO) do
        IO.println s!"B0_ELEMENT_PHASE reader.operand.slotSelect.before name={name} index={index} raw={(← IO.getNumHeartbeats)}"
      let value ← liftM <| SourceReadM.select { selected with value } (some type)
      liftM (m := IO) do
        IO.println s!"B0_ELEMENT_PHASE reader.operand.slotSelect.after name={name} index={index} raw={(← IO.getNumHeartbeats)}"
      pure value
    let type ← liftM (m := MetaM) <| instantiateMVars (← inferType argument)
    let value ← if operands.size == 1 then do
        let some operand := operands[0]?
          | liftM (m := TermElabM) <| throwError "the source operation requires its original operand"
        readOperand operand type
      else do
        liftM (m := IO) do
          IO.println s!"B0_ELEMENT_PHASE reader.tuple.before name={name} raw={(← IO.getNumHeartbeats)}"
        let value ← ExceptT.mk <| sourceTupleApplicable operands type fun source type =>
          (readOperand source type).run
        liftM (m := IO) do
          IO.println s!"B0_ELEMENT_PHASE reader.tuple.after name={name} raw={(← IO.getNumHeartbeats)}"
        pure value
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE reader.application.before name={name} raw={(← IO.getNumHeartbeats)}"
    let value ← elabAppArgs function #[] #[Arg.expr value] none false false
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE reader.application.after name={name} raw={(← IO.getNumHeartbeats)}"
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE reader.output.before name={name} raw={(← IO.getNumHeartbeats)}"
    let value ← if operation.outputTransport then do
        let some comparison := operation.comparison
          | liftM (m := TermElabM) <| throwError "the source result lost its supplied comparison"
        let forward ← mkAppM ``CategoryTheory.Iso.hom #[comparison]
        let forward ← sourceSetFunction forward
        liftM <| elabRetainedSourceApplication forward #[value] expected
      else if operation.outputDomain then mkExpectedTypeHint value domain
      else pure value
    liftM (m := IO) do
      IO.println s!"B0_ELEMENT_PHASE reader.output.after name={name} raw={(← IO.getNumHeartbeats)}"
    return (⟨value, none⟩ : NativeSourceJudgement)

/-- Ordinary operation formation with explicit applicability of its own typed operands.
Selected family, evidence, instance and recursive-reader errors remain exceptions. -/
def elementOperationApplicable (context : ReadContext)
    (name : String) (operands numerals : Array (TSyntax `cas_term))
    (known : Array (Option Expr)) (domainHint : Option Expr) :
    SourceReadM (Except MessageData NativeSourceJudgement) :=
  (elementOperationCore context name operands numerals known domainHint).run

def elementOperation (context : ReadContext)
    (name : String) (operands numerals : Array (TSyntax `cas_term))
    (known : Array (Option Expr)) (domainHint : Option Expr) :
    SourceReadM NativeSourceJudgement := do
  match ← elementOperationApplicable context name operands numerals known domainHint with
  | .ok value => pure value
  | .error message => liftM (m := TermElabM) <| throwError message

def action (context : ReadContext) :
    TSyntax `cas_term → TSyntax `cas_term → SourceReadM NativeSourceJudgement :=
  let readExpression := @ReadContext.readExpression context
  let categoryOf := context.categoryOf
  let expected := context.expected
  let elementOperation := elementOperation context
  fun (left right : TSyntax `cas_term) => do
    let rightExpected := if sourceNumeric right.raw then expected else none
    let value ← readExpression categoryOf right rightExpected
    elementOperation "•" #[left, right] #[] #[none, some value.value]
      (some (← inferType value.value))

/-- All declared juxtaposition readings compete at the same original typed operands.
Every successful native state is retained, so the unique chosen reading is not replayed.
An exception from a matched reader is never discarded to choose another interpretation. -/
def juxtapose (context : ReadContext) :
    TSyntax `cas_term → TSyntax `cas_term → SourceReadM NativeSourceJudgement :=
  let readExpression := @ReadContext.readExpression context
  let categoryOf := context.categoryOf
  let expected := context.expected
  fun (left right : TSyntax `cas_term) => do
    let rightExpected := if sourceNumeric right.raw then expected else none
    let rightValue ← readExpression categoryOf right rightExpected
    let leftValue ← if sourceNumeric left.raw then pure none
      else pure (some (← readExpression categoryOf left none))
    let names ← sourceJuxtapositionNames categoryOf leftValue rightValue
    let unavailable : MessageData :=
      "no declared juxtaposition reading accepts the original operands"
    let direct : Array (SourceReadM (Except MessageData NativeSourceJudgement)) :=
      leftValue.toArray.flatMap fun originalLeft => #[do
        let pair ← mkAppM ``Prod #[← inferType originalLeft.value, ← inferType rightValue.value]
        let some action ← sourceMorphismFrom? "•" pair | return .error unavailable
        let function ← sourceSetFunction action
        let argument ← mkAppM ``Prod.mk #[originalLeft.value, rightValue.value]
        return .ok ⟨← elabAppArgs function #[] #[Arg.expr argument] none false false, none⟩,
      do
        let result ← sourceDirectApplicationApplicable? originalLeft.value fun domain =>
          retainedOperandApplicable right rightValue.value domain
        match result with
        | .ok (some value) => return .ok ⟨value, none⟩
        | .ok none | .error _ => return .error unavailable]
    let trials := direct ++ names.map fun name => do
        let owner ← if name == "•" then pure (some (← inferType rightValue.value)) else pure none
        elementOperationApplicable context name #[left, right] #[]
          #[leftValue.map (·.value), some rightValue.value] owner
    match ← SourceReadM.chooseApplicable trials unavailable
        m!"juxtaposition has several declared readings of its original operands" with
    | .ok value => return value
    | .error _ =>
      if let some left := leftValue then
        let type ← inferType left.value
        let domains ← sourceOperationDomains categoryOf type none #[type]
        if domains.isEmpty && (left.category.any (·.role == .morphism) ||
            (← whnf type).isForall) then
          liftM (m := TermElabM) <| CasCatalogue.throwUnsupportedSource
            "callable juxtaposition requires its declared action and application comparison"
      liftM (m := TermElabM) <| CasCatalogue.throwStratum .invalid
        "no declared juxtaposition reading accepts the original operands"

def relation (context : ReadContext) :
    String → TSyntax `cas_term → TSyntax `cas_term → SourceReadM NativeSourceJudgement :=
  let readExpression := @ReadContext.readExpression context
  let categoryOf := context.categoryOf
  let elementOperation := elementOperation context
  fun (name : String) (left right : TSyntax `cas_term) => do
    -- The public precedence grammar places a trailing domain on the right operand.
    -- Its actual selected structure types both operands through the registered map.
    match right with
    | `(cas_term| $operand:cas_term in $domain:cas_term) =>
      let domain ← sourceCarrier (← readExpression categoryOf domain none)
      elementOperation name #[left, operand] #[] #[] (some domain.value)
    | _ => elementOperation name #[left, right] #[] #[] none

end SourceReader

end CasCompiler
