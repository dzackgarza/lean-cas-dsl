module

public import CasCompiler.Elaborate
public import CasCompiler.Syntax
public import Lean.Meta.Check

public section

namespace CasCompiler

open Lean Meta Elab Term

/-- Check actual native evidence in the explicit mathematical source interpretation, then
retain its full positional proof function. No rebuilt local escapes that interpretation. -/
opaque SourceReadM.prove (proposition : Expr)
    (prepare : Expr → Array Expr → TermElabM Expr)
    (sources : Array Expr := #[]) : SourceReadM Expr := do
  let original ← get
  let formals ← original.context.bindings.filterM fun binding => do
    return binding.originalSource.isNone && (← binding.expression.fvarId!.getDecl).value?.isNone
  let function ← liftM (m := TermElabM) <| controlAt MetaM fun run =>
    original.context.withOriginalSources (#[proposition] ++ sources) fun expressions =>
      run do
        let expected := expressions[0]!
        unless ← isProp expected do
          throwError "source proof checking requires a proposition"
        let proof ← instantiateMVars (← prepare expected (expressions.extract 1 expressions.size))
        unless ← isDefEq (← inferType proof) expected do
          throwError (← mkTypeMismatchError none proof (← inferType proof) expected)
        checkWithKernel proof
        let locals := (← getLCtx).foldl
          (fun result declaration => result.push (mkFVar declaration.fvarId)) #[]
        unless locals.size == original.context.bindings.size do
          throwError "source proof preparation changed the original native telescope"
        -- Keep every positional formal. Native abstraction also retains let dependencies
        -- of later formal types and retained let values. Unused definitions remain in the
        -- complete source context instead of being copied into every generated proof.
        let function ← mkLambdaFVars locals proof (usedOnly := false) (usedLetOnly := true)
        checkWithKernel function
        return function
  let mut proof := function
  for formal in formals do
    let .forallE _ type _ _ ← whnfR (← inferType proof)
      | liftM (m := TermElabM) <| throwError "source proof closure lost an original formal position"
    let selected := (← SourceReadM.selection? formal.expression).getD {
      value := formal.expression }
    let value ← SourceReadM.select { selected with value := formal.expression } (some type)
    proof := mkApp proof value
  checkWithKernel proof
  SourceReadM.select { value := proof } (some proposition)

/-- Check an explicitly supplied source proof at an independently prepared proposition.
Reuse: native expected-type elaboration and stable-ID context transport. The source hypothesis
and proof remain formal; this operation accepts no computational response as evidence. -/
opaque SourceSession.proof (session : SourceSession) (stx : TSyntax `cas_term)
    (obligation : ClosedTerm) (selections : SourceSelectionScope ClosedTerm := {}) :
    TermElabM SourceTerm := withRef stx do
  let `(cas_term| proof($evidence:term)) := stx
    | throwError "source evidence requires an explicit proof term"
  session.elaborateScoped evidence do
    let proposition ← session.readClosed evidence obligation selections
    SourceReadM.prove proposition (fun expected _ => sourceFormalProof evidence expected)

end CasCompiler
