module

public import CasCompiler.Elaborate
public import CasCompiler.Syntax
public import Lean.Meta.Check

public section

namespace CasCompiler

open Lean Meta Elab Term

/-- Check actual native evidence in the explicit mathematical source interpretation, then
retain its full positional proof function. No rebuilt local escapes that interpretation. -/
opaque SourceReadM.prove (proposition : Expr)
    (prepare : Expr → Array Expr → TermElabM Expr)
    (sources : Array Expr := #[]) : SourceReadM Expr := do
  let original ← get
  let formals ← original.context.bindings.filterM fun binding => do
    return binding.originalSource.isNone && (← binding.expression.fvarId!.getDecl).value?.isNone
  IO.println s!"B0_PROOF_PHASE scope.open.before raw={← IO.getNumHeartbeats}"
  let function ← liftM (m := TermElabM) <| controlAt MetaM fun run =>
    original.context.withOriginalSources (#[proposition] ++ sources) fun expressions =>
      run do
        IO.println s!"B0_PROOF_PHASE scope.open.after raw={← IO.getNumHeartbeats}"
        let expected := expressions[0]!
        unless ← isProp expected do
          throwError "source proof checking requires a proposition"
        IO.println s!"B0_PROOF_PHASE prepare.before raw={← IO.getNumHeartbeats}"
        let proof ← instantiateMVars (← prepare expected (expressions.extract 1 expressions.size))
        IO.println s!"B0_PROOF_PHASE prepare.after raw={← IO.getNumHeartbeats}"
        IO.println s!"B0_PROOF_PHASE proof.type.before raw={← IO.getNumHeartbeats}"
        unless ← isDefEq (← inferType proof) expected do
          throwError (← mkTypeMismatchError none proof (← inferType proof) expected)
        IO.println s!"B0_PROOF_PHASE proof.type.after raw={← IO.getNumHeartbeats}"
        IO.println s!"B0_PROOF_PHASE proof.kernel.before raw={← IO.getNumHeartbeats}"
        checkWithKernel proof
        IO.println s!"B0_PROOF_PHASE proof.kernel.after raw={← IO.getNumHeartbeats}"
        let locals := (← getLCtx).foldl
          (fun result declaration => result.push (mkFVar declaration.fvarId)) #[]
        unless locals.size == original.context.bindings.size do
          throwError "source proof preparation changed the original native telescope"
        -- Keep every positional formal. Native abstraction also retains let dependencies
        -- of later formal types and retained let values. Unused definitions remain in the
        -- complete source context instead of being copied into every generated proof.
        IO.println s!"B0_PROOF_PHASE closure.abstract.before raw={← IO.getNumHeartbeats}"
        let function ← mkLambdaFVars locals proof (usedOnly := false) (usedLetOnly := true)
        IO.println s!"B0_PROOF_PHASE closure.abstract.after raw={← IO.getNumHeartbeats}"
        IO.println s!"B0_PROOF_PHASE closure.kernel.before raw={← IO.getNumHeartbeats}"
        checkWithKernel function
        IO.println s!"B0_PROOF_PHASE closure.kernel.after raw={← IO.getNumHeartbeats}"
        return function
  IO.println s!"B0_PROOF_PHASE scope.return.after raw={← IO.getNumHeartbeats}"
  let mut proof := function
  IO.println s!"B0_PROOF_PHASE reapply.before raw={← IO.getNumHeartbeats}"
  for formal in formals do
    IO.println s!"B0_PROOF_PHASE formal.domain.before raw={← IO.getNumHeartbeats}"
    let .forallE _ type _ _ ← whnfR (← inferType proof)
      | liftM (m := TermElabM) <| throwError "source proof closure lost an original formal position"
    IO.println s!"B0_PROOF_PHASE formal.domain.after raw={← IO.getNumHeartbeats}"
    IO.println s!"B0_PROOF_PHASE formal.native.before raw={← IO.getNumHeartbeats}"
    let actual ← inferType formal.expression
    let nativeFits ← withoutModifyingState (isDefEq actual type)
    IO.println s!"B0_PROOF_PHASE formal.native.after raw={← IO.getNumHeartbeats}"
    let value ← if nativeFits then do
        -- Keep the exact original formal when no source interpretation is needed.
        -- Commit any assignments checked by the probe before applying the function.
        IO.println s!"B0_PROOF_PHASE formal.commit.before raw={← IO.getNumHeartbeats}"
        unless ← isDefEq actual type do
          liftM (m := TermElabM) <| throwError "source proof closure changed its checked formal type"
        IO.println s!"B0_PROOF_PHASE formal.commit.after raw={← IO.getNumHeartbeats}"
        pure formal.expression
      else do
        IO.println s!"B0_PROOF_PHASE formal.selection.before raw={← IO.getNumHeartbeats}"
        let selected := (← SourceReadM.selection? formal.expression).getD {
          value := formal.expression }
        IO.println s!"B0_PROOF_PHASE formal.select.before raw={← IO.getNumHeartbeats}"
        let value ← SourceReadM.select { selected with value := formal.expression } (some type)
        IO.println s!"B0_PROOF_PHASE formal.select.after raw={← IO.getNumHeartbeats}"
        pure value
    proof := mkApp proof value
    IO.println s!"B0_PROOF_PHASE formal.apply.after raw={← IO.getNumHeartbeats}"
  IO.println s!"B0_PROOF_PHASE reapply.after raw={← IO.getNumHeartbeats}"
  -- Expose the supplied proof after eliminating only this explicit closure application.
  -- Native helper declarations and authored source inputs remain in the returned term.
  IO.println s!"B0_PROOF_PHASE headBeta.before raw={← IO.getNumHeartbeats}"
  proof := proof.headBeta
  IO.println s!"B0_PROOF_PHASE headBeta.after raw={← IO.getNumHeartbeats}"
  IO.println s!"B0_PROOF_PHASE result.kernel.before raw={← IO.getNumHeartbeats}"
  checkWithKernel proof
  IO.println s!"B0_PROOF_PHASE result.kernel.after raw={← IO.getNumHeartbeats}"
  IO.println s!"B0_PROOF_PHASE result.native.before raw={← IO.getNumHeartbeats}"
  let actual ← inferType proof
  let nativeFits ← withoutModifyingState (isDefEq actual proposition)
  IO.println s!"B0_PROOF_PHASE result.native.after raw={← IO.getNumHeartbeats}"
  if nativeFits then
    IO.println s!"B0_PROOF_PHASE result.commit.before raw={← IO.getNumHeartbeats}"
    unless ← isDefEq actual proposition do
      liftM (m := TermElabM) <| throwError "source proof closure changed its original proposition"
    IO.println s!"B0_PROOF_PHASE result.commit.after raw={← IO.getNumHeartbeats}"
    return proof
  IO.println s!"B0_PROOF_PHASE result.select.before raw={← IO.getNumHeartbeats}"
  let selected ← SourceReadM.select { value := proof } (some proposition)
  IO.println s!"B0_PROOF_PHASE result.select.after raw={← IO.getNumHeartbeats}"
  return selected

/-- Check an explicitly supplied source proof at an independently prepared proposition.
Reuse: native expected-type elaboration and stable-ID context transport. The source hypothesis
and proof remain formal; this operation accepts no computational response as evidence. -/
opaque SourceSession.proof (session : SourceSession) (stx : TSyntax `cas_term)
    (obligation : ClosedTerm) (selections : SourceSelectionScope ClosedTerm := {}) :
    TermElabM SourceTerm := withRef stx do
  let `(cas_term| proof($evidence:term)) := stx
    | throwError "source evidence requires an explicit proof term"
  session.elaborateScoped evidence do
    let proposition ← session.readClosed evidence obligation selections
    SourceReadM.prove proposition (fun expected _ => sourceFormalProof evidence expected)

end CasCompiler
