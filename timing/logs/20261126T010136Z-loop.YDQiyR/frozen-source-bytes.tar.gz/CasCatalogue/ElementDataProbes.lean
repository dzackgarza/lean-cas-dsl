module

import CasCatalogue.Realize
meta import CasCatalogue.Realize

open Lean Meta Elab Command Term
open CasCatalogue CasCatalogue.Language

/- Engineering checks only: decode typed data and reject malformed envelopes. No mathematical
acceptance answer is inferred from these implementation checks. -/
run_cmd liftTermElabM do
  let state ← registryState
  let selected ← (object state "ZMod" #[.nat 5] none).run {}
  let .object _ _ (some (entry, _)) _ _ := selected
    | throwError "probe selected object lost its registered identity"
  let descriptor := Json.mkObj [("ctor", toJson entry.id.raw),
    ("args", Json.arr #[toJson (5 : Nat)])]
  let type ← (semanticObject selected).run {}
  let node (tag : String) (args : Array Json) :=
    Json.mkObj [("ctor", toJson tag), ("args", Json.arr args)]
  let envelope (object data : Json) := node "element" #[object, data]
  let numeral := node "numeral" #[toJson (2 : Nat)]
  let arithmetic := node "add" #[numeral, node "neg" #[node "mul" #[numeral, numeral]]]
  for data in #[numeral, arithmetic] do
    let some (.ok point) ← ElementData.decode selected descriptor type (envelope descriptor data)
      | throwError "generic closed element arithmetic failed to decode"
    unless ← isTypeCorrect point do throwError "decoded element is not type correct"
  let wrongParameter := Json.mkObj [("ctor", toJson entry.id.raw),
    ("args", Json.arr #[toJson (7 : Nat)])]
  let wrongObject := Json.mkObj [("ctor", toJson "other-object"),
    ("args", Json.arr #[toJson (5 : Nat)])]
  for json in #[envelope wrongParameter numeral, envelope wrongObject numeral,
      envelope descriptor (node "numeral" #[toJson (-1 : Int)]),
      envelope descriptor (node "add" #[numeral]),
      envelope descriptor (node "arbitrary-declaration" #[]), node "element" #[]] do
    let some (.error _) ← ElementData.decode selected descriptor type json
      | throwError "malformed or incorrectly selected element data was accepted"
  let .none ← ElementData.decode selected descriptor type numeral
    | throwError "an unrecognized envelope was captured by element decoding"
  let polynomial ← (eval {} (← `(cas_term| ℤ[x]))).run {}
  let .element generator _ ← (ElementData.read polynomial (node "generator" #[])).run {}
    | throwError "registered generator data did not produce an element"
  unless ← isTypeCorrect generator do throwError "registered generator data is not typed"

/- Engineering regression: encoding a point retains its complete selected structural form. -/
open CasCatalogue.Realize

run_cmd liftTermElabM do
  let .ok parsed := Parser.runParserCategory (← getEnv) `cas_stmt "assert 2 + 3 = 5"
    | throwError "selected-element regression did not parse"
  let question ← interpret {} parsed
  let trace ← IO.mkRef question.trace
  let harness ← Harness.empty
  let mut transported := 0
  for (point, node) in question.trace.toArray do
    let .elementNumeral _ target selected := node | continue
    let selectedWire ← realize harness trace "the selected structure" selected
    if selectedWire.form matches .object _ then continue
    let wire ← realize harness trace "the retained numeral point" point
    let .ok args := (wire.json.getObjVal? "args").bind (·.getArr?)
      | throwError "selected element lost its envelope"
    unless args.size == 2 && args[0]! == selectedWire.json do
      throwError "selected element changed its complete structural descriptor"
    unless wire.form.id == selectedWire.form.id &&
        wire.form.category == selectedWire.form.category do
      throwError "selected element changed its declared computational form"
    let some (_, actualTarget) := Language.homEnds? (← inferType wire.value)
      | throwError "selected element lost its typed point endpoints"
    unless ← Lean.Meta.isDefEq actualTarget target do
      throwError "selected element changed its formal target"
    transported := transported + 1
  unless transported > 0 do
    throwError "selected-element regression did not exercise a transported structure"

/- Engineering regression: the binder's fixed domain retains its structured parameter sources. -/
run_cmd withoutModifyingEnv <| liftTermElabM do
  let .ok parsed := Parser.runParserCategory (← getEnv) `cas_stmt
      "assert lim_{t → ∞} 1/t = 0"
    | throwError "binder-domain regression did not parse"
  let question ← interpret {} parsed
  let trace : Trace ← IO.mkRef question.trace
  let harness ← Harness.empty
  let mut structured := 0
  for (_, node) in question.trace.toArray do
    let .binder _ _ domain _ _ := node | continue
    let some (.object expectedId parameters) ← Trace.node? trace domain
      | throwError "the declared binder domain lost its registered constructor"
    let wire ← realize harness trace "the binder's declared domain" domain
    let .object entry := wire.form
      | throwError "the declared binder domain changed its registered form"
    unless entry.id == expectedId do
      throwError "the declared binder domain changed its registered identity"
    let .ok arguments := (wire.json.getObjVal? "args").bind (·.getArr?)
      | throwError "the binder domain has no complete parameter data"
    unless arguments.size == parameters.size do
      throwError "the binder domain omitted a declared parameter"
    for (parameter, argument) in parameters.zip arguments do
      let parameterType ← inferType parameter
      if (← whnfR parameterType).isSort || (← isProp parameterType) then continue
      let selected ← realize harness trace "the binder's fixed structured parameter" parameter
      unless argument == selected.json do
        throwError "the binder domain changed its complete structured parameter data"
      structured := structured + 1
  unless structured > 0 do
    throwError "binder-domain regression did not exercise a structured parameter"
