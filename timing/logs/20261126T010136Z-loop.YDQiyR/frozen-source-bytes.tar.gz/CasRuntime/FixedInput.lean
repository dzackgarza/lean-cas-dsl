module

public import CasRuntime.PreparedRequest
public import CasRuntime.InputRoute

public section

namespace CasRuntime

open Lean Meta CasCompiler

/-- Select fixed fields without executing a lazy input or invoking a resolver. A selected
callable follows its retained projection/application history or original producing role and context.
Original parameter bindings and formal argument ordinals remain separate through every step.
The optional resolver is retained for caller compatibility and is never invoked here.
Reuse: ApplicationLayout.inputProjectionThrough, ValueGraph.projectionOrigin,
ValueGraph.applicationOrigin and native paths. -/
opaque PreparedRequest.fixedInputFor (request : PreparedRequest) (graph : ValueGraph)
    (source : SourceLayout)
    (resolve : Option (FixedInput → MetaM (ValueGraph × ValueBinding)) := none) :
    MetaM (Option FixedInput) := do
  let _ := resolve
  let some original := request.origin.application | return none
  original.fixedInputAt graph (← request.source.projectionPathTo source)

end CasRuntime
