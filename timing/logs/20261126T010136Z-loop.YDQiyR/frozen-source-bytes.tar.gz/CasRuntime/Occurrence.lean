module

public import CasRuntime.Value
public import CasContract.Registration

public section

namespace CasRuntime

/-- The already selected registration and frozen profile; this record performs no selection. -/
structure DispatchIdentity where
  manifestDigest : String
  registration : CasCatalogue.Registration
  profileDigest : String
  deriving DecidableEq, BEq, Repr

/-- A selected primitive or the exact stored native code node and local token.
Native dispatch retains its existing owner in DispatchReservation.connection. -/
inductive DispatchTarget where
  | primitive (identity : DispatchIdentity)
  | native (value : RuntimeId .value) (token : String)
  deriving BEq, Repr

structure DispatchReservation where
  private mk ::
  occurrence : RuntimeId .occurrence
  transaction : RuntimeId .transaction
  selected : DispatchTarget
  connection : ConnectionGeneration
  dependencies : Array ConnectionGeneration

inductive ReservationFailure
  | wrongWorker | unknownOccurrence | consumed | staleOwner | referenceOutsideGraph
  | invalidExport | wrongConnection
  deriving BEq, Repr

private inductive OccurrenceStatus
  | fresh
  | abandoned
  | pending (reservation : DispatchReservation)
  | sent (reservation : DispatchReservation)
  | consumed (reservation : DispatchReservation)

/-- Only resource status and pending locators live here; completed payloads belong to ValueGraph.
Reference: Lean v4.33.0 Std.Sync.Mutex and Std.HashMap. -/
structure OccurrenceLedger where
  private mk ::
  owners : OwnerRegistry
  private state : Std.Mutex (Std.HashMap (RuntimeId .occurrence) OccurrenceStatus)

opaque OccurrenceLedger.new (owners : OwnerRegistry) : BaseIO OccurrenceLedger := do
  return ⟨owners, ← Std.Mutex.new {}⟩

/-- Allocate an invocation before elaboration, normalization or realization selection can merge it. -/
opaque OccurrenceLedger.allocate (ledger : OccurrenceLedger) : BaseIO (RuntimeId .occurrence) := do
  let id ← ledger.owners.identities.fresh .occurrence
  ledger.state.atomically do
    modify fun state => state.insert id .fresh
  return id

/-- Owner retirement and the one-use reservation cannot interleave.
The nested ledger section holds no engine I/O and stores no value or completion payload. -/
private def reserveTarget (ledger : OccurrenceLedger) (id : RuntimeId .occurrence)
    (transaction : RuntimeId .transaction) (selected : DispatchTarget) (connection : Connection)
    (graph : ValueGraph) (arguments : Array ValueBinding) :
    BaseIO (Except ReservationFailure DispatchReservation) := do
  unless id.worker == ledger.owners.worker && transaction.worker == ledger.owners.worker &&
      graph.worker == ledger.owners.worker && connection.generation.worker == ledger.owners.worker do
    return .error .wrongWorker
  let .ok dependencies := graph.requiredOwners arguments
    | return .error .referenceOutsideGraph
  let dependencies := if dependencies.contains connection.generation then dependencies
    else dependencies.push connection.generation
  let result ← ledger.owners.atomicallyWhileLive dependencies <| ledger.state.atomically do
    let state ← get
    match state[id]? with
    | none => return .error .unknownOccurrence
    | some .fresh =>
      let reservation : DispatchReservation :=
        ⟨id, transaction, selected, connection.generation, dependencies⟩
      set (state.insert id (.pending reservation))
      return .ok reservation
    | some .abandoned | some (.pending _) | some (.sent _) | some (.consumed _) => return .error .consumed
  match result with
  | some reserved => return reserved
  | none => return .error .staleOwner

/-- Reserve the already selected primitive under the shared one-use owner/ledger transition. -/
opaque OccurrenceLedger.reserve (ledger : OccurrenceLedger) (id : RuntimeId .occurrence)
    (transaction : RuntimeId .transaction) (selected : DispatchIdentity) (connection : Connection)
    (graph : ValueGraph) (arguments : Array ValueBinding) :
    BaseIO (Except ReservationFailure DispatchReservation) :=
  reserveTarget ledger id transaction (.primitive selected) connection graph arguments

/-- Resolve the actual stored code and reserve only its original supplying connection.
Reuse: ValueGraph.callable and the same atomic reservation as primitive dispatch.
The complete callable reference brings its actual captures and dependent owner closure. -/
opaque OccurrenceLedger.reserveExport (ledger : OccurrenceLedger) (id : RuntimeId .occurrence)
    (transaction : RuntimeId .transaction) (callable : ValueBinding) (connection : Connection)
    (graph : ValueGraph) (arguments : Array ValueBinding) :
    BaseIO (Except ReservationFailure DispatchReservation) := do
  let .ok code := graph.callable callable | return .error .invalidExport
  let some node := graph.find code.value | return .error .referenceOutsideGraph
  let .ownedToken owner token _ := node.payload.data | return .error .invalidExport
  if token.isEmpty then return .error .invalidExport
  unless owner == connection.generation do return .error .wrongConnection
  reserveTarget ledger id transaction (.native code.value token) connection graph
    (arguments.push callable)

/-- Inspect coordination state; only the atomic reservation can authorize dispatch. -/
opaque OccurrenceLedger.isFresh (ledger : OccurrenceLedger) (id : RuntimeId .occurrence) :
    BaseIO Bool := ledger.state.atomically do
  return (← get)[id]? matches some .fresh

/-- A failed claimed producer cannot acquire a new dispatch right after rollback. -/
opaque OccurrenceLedger.abandon (ledger : OccurrenceLedger) (id : RuntimeId .occurrence) :
    BaseIO Unit := ledger.state.atomically do
  let state ← get
  if state[id]? matches some .fresh then set (state.insert id .abandoned)

/-- Return only the locator belonging to this exact active transaction. -/
opaque OccurrenceLedger.pendingFor (ledger : OccurrenceLedger) (id : RuntimeId .occurrence)
    (transaction : RuntimeId .transaction) : BaseIO (Option DispatchReservation) :=
  ledger.state.atomically do
    match (← get)[id]? with
    | some (.pending reservation) | some (.sent reservation) =>
      return if reservation.transaction == transaction then some reservation else none
    | _ => return none

/-- Whether this exact reservation's occurrence has been sent and not yet retired: the state in
which the provider may suspend it and the kernel may resume it (execution contract §6).
A resume continues that one dispatch; it is not a second dispatch right. -/
opaque OccurrenceLedger.wasSent (ledger : OccurrenceLedger) (reservation : DispatchReservation) :
    BaseIO Bool := ledger.state.atomically do
  match (← get)[reservation.occurrence]? with
  | some (.sent active) =>
    return active.transaction == reservation.transaction &&
      active.connection == reservation.connection && active.selected == reservation.selected
  | _ => return false

/-- Commit this exact reserved invocation to one send, after rechecking actual owners.
The pending locator remains available for scope and reply admission. Engine I/O follows
outside both locks; a later connection loss cannot grant another send.
Reuse: OwnerRegistry.atomicallyWhileLive and the existing one-use ledger transition. -/
opaque OccurrenceLedger.commitSend (ledger : OccurrenceLedger)
    (reservation : DispatchReservation) : BaseIO (Except ReservationFailure Unit) := do
  let result ← ledger.owners.atomicallyWhileLive reservation.dependencies <|
      ledger.state.atomically do
    let state ← get
    let some status := state[reservation.occurrence]?
      | return .error .unknownOccurrence
    match status with
    | .pending active =>
      unless active.transaction == reservation.transaction &&
          active.connection == reservation.connection && active.selected == reservation.selected do
        return .error .consumed
      set (state.insert reservation.occurrence (.sent active))
      return .ok ()
    | .fresh | .abandoned | .sent _ | .consumed _ => return .error .consumed
  return result.getD (.error .staleOwner)

/-- Retire once. The consumed tombstone remains outside all semantic snapshots. -/
opaque OccurrenceLedger.retire (ledger : OccurrenceLedger) (reservation : DispatchReservation) :
    BaseIO Bool :=
  ledger.state.atomically do
    let state ← get
    let some status := state[reservation.occurrence]? | return false
    let active ← match status with
      | .pending active | .sent active => pure active
      | .fresh | .abandoned | .consumed _ => return false
    unless active.transaction == reservation.transaction &&
        active.connection == reservation.connection && active.selected == reservation.selected do
      return false
    set (state.insert reservation.occurrence (.consumed active))
    return true

end CasRuntime
