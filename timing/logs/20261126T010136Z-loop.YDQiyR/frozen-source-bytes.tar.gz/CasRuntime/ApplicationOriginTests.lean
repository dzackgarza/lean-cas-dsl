module

import CasRuntime.PreparedRequest
public meta import Lean.Elab.Command
meta import CasRuntime.PreparedRequest

open Lean Meta CasCompiler CasRuntime

-- Native source families determine which actual arguments a produced field needs.
run_cmd Lean.Elab.Command.liftTermElabM do
  let empty ← ContextTelescope.capture #[]
  let indexRole ← SourceLayout.ofTerm (← empty.close (mkNatLit 7))
  let type ← Elab.Term.elabTermAndSynthesize
    (← `((n : Nat) → Nat × Fin (n + 1))) (some (mkSort (.succ .zero)))
  let owners ← liftM (m := IO) OwnerRegistry.new
  let owner ← liftM (m := IO) <| owners.spawn { cmd := "/bin/cat" }
  let codeOwner ← liftM (m := IO) <| owners.spawn { cmd := "/bin/cat" }
  try
    let token ← liftM (m := IO) do
      owner.child.stdin.putStr "actual argument index\n"
      owner.child.stdin.flush
      return (← owner.child.stdout.getLine).trimAscii.toString
    let codeToken ← liftM (m := IO) do
      codeOwner.child.stdin.putStr "actual callable code\n"
      codeOwner.child.stdin.flush
      return (← codeOwner.child.stdout.getLine).trimAscii.toString
    let program ← liftM (m := BaseIO) (owners.identities.fresh .program)
    let occurrence ← liftM (m := BaseIO) (owners.identities.fresh .occurrence)
    withLocalDeclD `f type fun f => do
      let context ← ContextTelescope.capture #[{
        id := ⟨"application-origin", 0⟩, role := .parameter, expression := f }]
      let role ← SourceLayout.ofTerm (← context.close f)
      let (older, callable) ← liftM (m := IO) <|
        (ValueGraph.empty owners.identities).stage owners.identities
        { program, occurrence, role, parameters := #[none] } (.ownedExport codeOwner codeToken #[])
      let (graph, index) ← liftM (m := IO) <| older.stage owners.identities
        { program, occurrence, role := indexRole, parameters := #[] } (.ownedExport owner token #[])
      let .ok argument := RuntimeArgument.ofValue graph 0 index
        | throwError "the actual source index is outside its graph"
      let request ← PreparedRequest.forApplication owners.identities program occurrence context callable
        #[← context.close (mkNatLit 7)] #[argument] #[]
      -- The native result program retains the original formal slot, not the supplied numeral.
      let expectedFamily ← context.close
        (mkLambda `n .default (mkConst ``Nat) (mkApp f (.bvar 0)))
      let observedApplication :=
        (request.observation.native.getObjValD "request").getObjValD "application"
      let observedFamily := observedApplication.getObjValD "resultTermFamily"
      let .ok expressionIndex := observedFamily.getObjValAs? Nat "expression"
        | throwError "the native application observation lost its original result term family"
      let .ok typeIndex := observedFamily.getObjValAs? Nat "type"
        | throwError "the native result term family lost its complete dependent type"
      let .ok nodes := CasTools.NativeExpression.decodeNodes
          (request.observation.native.getObjValD "nativeExpressions")
        | throwError "the result term family is outside its exact native expression graph"
      unless nodes[expressionIndex]? == some expectedFamily.expression &&
          nodes[typeIndex]? == some expectedFamily.type do
        throwError "the application observation substituted an actual result for its original family"
      let .ok familyContext := observedFamily.getObjValAs? (Array Json) "context"
        | throwError "the original result family lost its source binding table"
      unless familyContext.size == 1 && familyContext[0]!.getObjValD "id" ==
          Json.mkObj [("session", toJson "application-origin"), ("serial", toJson (0 : Nat))] do
        throwError "the original result family changed its captured callable binding"
      let expectedReadable ← expectedFamily.withOpen fun _ expression =>
        return (← ppExpr expression).pretty
      let readableFamily := (request.observation.readable.getObjValD "application").getObjValD
        "resultTermFamily"
      unless readableFamily.getObjValD "expression" == toJson expectedReadable do
        throwError "the readable application observation changed its original result term family"
      let some record := request.record | throwError "the source result record is absent"
      let some first := record.fields[0]? | throwError "the independent source field is absent"
      let some second := record.fields[1]? | throwError "the dependent source field is absent"
      let finite ← RecordLayout.ofSource second.layout
      let some valueField := finite.fields[0]? | throwError "the nested source data field is absent"
      let independent ← request.originFor first.layout
      let dependent ← request.originFor second.layout
      let nested ← request.originFor valueField.layout
      let unrelated ← SourceLayout.ofTerm (← context.close (mkNatLit 1))
      let failure : Option Exception ← try
        discard <| request.originFor unrelated
        pure none
      catch error => pure (some error)
      let some failure := failure | throwError "result provenance accepted an unrelated source role"
      unless (← failure.toMessageData.toString).startsWith
          "the source role is not its prepared application result projection" do throw failure
      let some whole := request.origin.application
        | throwError "the prepared result lost its actual application provenance"
      let some left := independent.application
        | throwError "the independent result lost its application table"
      let some right := dependent.application
        | throwError "the dependent result lost its application table"
      let some inner := nested.application
        | throwError "the nested result lost its application table"
      unless whole.arguments.size == 1 &&
          (whole.arguments[0]?.bind id).map (·.value) == some index.value &&
          whole.callable.map (·.value) == some callable.value &&
          whole.dependencies == #[0] && right.dependencies == #[0] &&
          left.dependencies.isEmpty && inner.dependencies.isEmpty do
        throwError "result provenance changed an actual argument or a field's native dependencies"
      let hidden ← liftM (m := IO) do
        try
          discard <| older.stage owners.identities dependent (.portable "0".toUTF8)
          pure false
        catch error => pure (error.toString.endsWith "the value reference is outside the visible graph")
      unless hidden do throwError "application provenance recovered an index absent from its graph"
      let (graph, leftValue) ← liftM (m := IO) <|
        graph.stage owners.identities independent (.portable "0".toUTF8)
      let (graph, innerValue) ← liftM (m := IO) <|
        graph.stage owners.identities nested (.portable "0".toUTF8)
      let (graph, rightValue) ← liftM (m := IO) <|
        graph.stage owners.identities dependent (.product #[innerValue])
      let (graph, result) ← liftM (m := IO) <|
        graph.stage owners.identities request.origin (.product #[leftValue, rightValue])
      let some node := graph.find leftValue.value | throwError "the independent result is absent"
      unless node.references.map (·.value) == #[callable.value, index.value] && node.owners.isEmpty do
        throwError "an independent field lost argument visibility or acquired an unrelated owner"
      unless ← liftM (m := BaseIO) (graph.isAvailable owners result) do
        throwError "a result with a live argument index is unavailable"
      liftM (m := IO) <| owners.close codeOwner.generation
      unless ← liftM (m := BaseIO) (graph.isAvailable owners result) do
        throwError "completed portable data retained the supplying callable's unrelated owner"
      liftM (m := IO) <| owners.close owner.generation
      for value in #[rightValue, result] do
        if ← liftM (m := BaseIO) (graph.isAvailable owners value) then
          throwError "a dependent result survived loss of its actual argument index owner"
      for value in #[leftValue, innerValue] do
        unless ← liftM (m := BaseIO) (graph.isAvailable owners value) do
          throwError "a field independent of the argument index lost its usable value"
  finally
    liftM (m := IO) <| owners.close owner.generation
    liftM (m := IO) <| owners.close codeOwner.generation

-- Lazy access retains the original application's context across a later source telescope.
run_cmd Lean.Elab.Command.liftTermElabM do
  let empty ← ContextTelescope.capture #[]
  let scalar ← SourceLayout.ofTerm (← empty.close (mkNatLit 7))
  let zero ← SourceLayout.ofTerm (← empty.close (mkNatLit 0))
  let owners ← liftM (m := IO) OwnerRegistry.new
  let contextOwner ← liftM (m := IO) <| owners.spawn { cmd := "/bin/cat" }
  let indexOwner ← liftM (m := IO) <| owners.spawn { cmd := "/bin/cat" }
  let accessOwner ← liftM (m := IO) <| owners.spawn { cmd := "/bin/cat" }
  let extraOwner ← liftM (m := IO) <| owners.spawn { cmd := "/bin/cat" }
  try
    let token (connection : Connection) (text : String) : IO String := do
      connection.child.stdin.putStr (text ++ "\n")
      connection.child.stdin.flush
      return (← connection.child.stdout.getLine).trimAscii.toString
    let program ← liftM (m := BaseIO) (owners.identities.fresh .program)
    let occurrence ← liftM (m := BaseIO) (owners.identities.fresh .occurrence)
    let (graph, contextValue) ← liftM (m := IO) <|
      (ValueGraph.empty owners.identities).stage owners.identities
        { program, occurrence, role := scalar, parameters := #[] }
        (.ownedExport contextOwner (← liftM (m := IO) <| token contextOwner "context index") #[])
    let (graph, index) ← liftM (m := IO) <| graph.stage owners.identities
      { program, occurrence, role := scalar, parameters := #[] }
      (.ownedExport indexOwner (← liftM (m := IO) <| token indexOwner "argument index") #[])
    let (graph, extra) ← liftM (m := IO) <| graph.stage owners.identities
      { program, occurrence, role := scalar, parameters := #[] }
      (.ownedExport extraOwner (← liftM (m := IO) <| token extraOwner "unused later binding") #[])
    let (graph, number) ← liftM (m := IO) <| graph.stage owners.identities
      { program, occurrence, role := zero, parameters := #[] } (.portable "0".toUTF8)
    withLocalDeclD `n (mkConst ``Nat) fun n => do
      let nBinding : LocalBinding := { id := ⟨"lazy-origin", 0⟩, role := .parameter, expression := n }
      let nContext ← ContextTelescope.capture #[nBinding]
      let functionType ← withLocalDeclD `k (mkConst ``Nat) fun k => do
        let bound := mkApp2 (mkConst ``Nat.add) (mkApp2 (mkConst ``Nat.add) n k) (mkNatLit 1)
        mkForallFVars #[k] (← mkAppM ``Prod #[mkConst ``Nat, mkApp (mkConst ``Fin) bound])
      let closedFunctionType ← nContext.close functionType
      withLocalDeclD `f functionType fun f => do
        let fBinding : LocalBinding := { id := ⟨"lazy-origin", 1⟩, role := .parameter, expression := f }
        let context ← ContextTelescope.capture #[nBinding, fBinding]
        let role ← SourceLayout.ofTerm (← context.close f)
        let (graph, callable) ← liftM (m := IO) <| graph.stage owners.identities
          { program, occurrence, role, parameters := #[some contextValue, none] } (.closure program #[])
        let .ok parameter := RuntimeParameter.ofValue graph nBinding.id contextValue
          | throwError "the original context value is outside its graph"
        let .ok argument := RuntimeArgument.ofValue graph 0 index
          | throwError "the original argument value is outside its graph"
        let request ← PreparedRequest.forApplication owners.identities program occurrence context callable
          #[← context.close (mkNatLit 7)] #[argument] #[parameter]
        let (graph, parent) ← liftM (m := IO) <| graph.stage owners.identities request.origin
          (.ownedExport accessOwner (← liftM (m := IO) <| token accessOwner "lazy record") #[])
        let parentType ← inferType (← request.source.source.inContext context)
        let closedParentType ← context.close parentType
        withLCtx {} #[] do
          withLocalDeclD `n (mkConst ``Nat) fun shadow => do
            let extraBinding : LocalBinding := {
              id := ⟨"lazy-current", 0⟩, role := .parameter, expression := shadow }
            withLocalDeclD `n (mkConst ``Nat) fun currentN => do
              let currentNBinding := { nBinding with expression := currentN }
              let prefixContext ← ContextTelescope.capture #[extraBinding, currentNBinding]
              let functionType ← closedFunctionType.inContext prefixContext
              withLocalDeclD `f functionType fun currentF => do
                let currentFBinding := { fBinding with expression := currentF }
                let prefixContext ← ContextTelescope.capture #[extraBinding, currentNBinding, currentFBinding]
                let parentType ← closedParentType.inContext prefixContext
                withLocalDeclD `r parentType fun r => do
                  let resultBinding : LocalBinding := {
                    id := ⟨"lazy-current", 1⟩, role := .result, expression := r }
                  let current ← ContextTelescope.capture
                    #[extraBinding, currentNBinding, currentFBinding, resultBinding]
                  let .ok extraParameter := RuntimeParameter.ofValue graph extraBinding.id extra
                    | throwError "the later unrelated context value is absent"
                  let .ok resultParameter := RuntimeParameter.ofValue graph resultBinding.id parent
                    | throwError "the lazy result is absent"
                  let parameters := #[extraParameter, parameter, resultParameter]
                  let environment ← RuntimeEnvironment.capture owners.worker current parameters
                  let .ok (some retained) := environment.lookup resultBinding.id
                    | throwError "the later source binding lost the actual lazy result"
                  let fieldOccurrence ← liftM (m := BaseIO) (owners.identities.fresh .occurrence)
                  let projection ← PreparedRequest.forProjection owners.identities program fieldOccurrence current graph retained 1 parameters
                  let origin ← projection.originFor projection.source
                  let some application := origin.application
                    | throwError "the projected result lost its originating application"
                  let some access := origin.access
                    | throwError "the projected result lost its actual access operand"
                  unless origin.parameters.size == 4 && application.parameters.size == 2 &&
                      application.path == #[``Prod.snd] &&
                      application.contextDependencies == #[0] && application.dependencies == #[0] &&
                      (application.parameters[0]?.bind id).map (·.value) == some contextValue.value &&
                      (application.arguments[0]?.bind id).map (·.value) == some index.value &&
                      access.value == parent.value && (← access.role.source.inContext current) == r do
                    throwError "projection changed its source planes, path or actual later-bound operand"
                  let document := projection.observation.native.getObjValD "request"
                  let .ok observedContext :=
                      (document.getObjValD "environment").getObjValAs? (Array Json) "context"
                    | throwError "projection observation lost its complete current source context"
                  let expectedIds := #[
                    Json.mkObj [("session", toJson "lazy-current"), ("serial", toJson (0 : Nat))],
                    Json.mkObj [("session", toJson "lazy-origin"), ("serial", toJson (0 : Nat))],
                    Json.mkObj [("session", toJson "lazy-origin"), ("serial", toJson (1 : Nat))],
                    Json.mkObj [("session", toJson "lazy-current"), ("serial", toJson (1 : Nat))]]
                  let .ok readable :=
                      projection.observation.readable.getObjValAs? (Array Json) "context"
                    | throwError "projection observation lost its prepared readable context"
                  unless observedContext.map (·.getObjValD "id") == expectedIds &&
                      readable.map (·.getObjValD "id") == expectedIds &&
                      observedContext[0]?.map (·.getObjValD "name") == some (toJson "n") &&
                      observedContext[1]?.map (·.getObjValD "name") == some (toJson "n") do
                    throwError "observation merged shadowed names or omitted unused bindings"
                  let checkSourceAddress (prepared : PreparedRequest) (path : Array Name) :
                      MetaM Unit := do
                    let requestDocument := prepared.observation.native.getObjValD "request"
                    let nativeSource := requestDocument.getObjValD "source"
                    let nativeAddress := nativeSource.getObjValD "inputProjection"
                    let sourceText := prepared.observation.readable.getObjValD "source"
                    let readableAddress := sourceText.getObjValD "inputProjection"
                    let target := Json.mkObj [("context", expectedIds[3]!)]
                    let nativePath := Json.arr (path.map CasTools.NativeExpression.nameJson)
                    unless nativeAddress.getObjValD "target" == target &&
                        nativeAddress.getObjValD "path" == nativePath &&
                        readableAddress.getObjValD "target" == target &&
                        readableAddress.getObjValD "path" == nativePath &&
                        readableAddress.getObjValD "displayPath" ==
                          toJson (path.map (·.toString (escape := false))) do
                      throwError "projection observation changed its exact source binding or native path"
                  checkSourceAddress projection #[``Prod.snd]
                  let observedOrigin := document.getObjValD "origin"
                  let observedApplication := observedOrigin.getObjValD "application"
                  let observedAccess := (observedOrigin.getObjValD "access").getObjValD "reference"
                  unless (observedOrigin.getObjValAs? (Array Json) "parameters").toOption.map
                        (·.size) == some 4 &&
                      (observedApplication.getObjValAs? (Array Json) "parameters").toOption.map
                        (·.size) == some 2 &&
                      observedApplication.getObjValD "path" ==
                        Json.arr #[CasTools.NativeExpression.nameJson ``Prod.snd] &&
                      observedAccess.getObjValD "value" == Json.mkObj [
                        ("worker", toJson parent.value.worker),
                        ("serial", toJson parent.value.serial)] do
                    throwError "observation lost its final application or access origin"
                  let (projected, point) ← liftM (m := IO) <|
                    graph.stage owners.identities origin (.product #[number])
                  let .ok dependencies := projected.requiredOwners #[point]
                    | throwError "the projected result is outside its graph"
                  unless dependencies.contains contextOwner.generation &&
                      dependencies.contains indexOwner.generation &&
                      !dependencies.contains accessOwner.generation &&
                      !dependencies.contains extraOwner.generation do
                    throwError "lazy projection lost its original application context or argument dependencies"
                  let nestedOccurrence ← liftM (m := BaseIO) (owners.identities.fresh .occurrence)
                  let nested ← PreparedRequest.forProjection owners.identities program nestedOccurrence current
                    projected point 0 parameters
                  let innerOrigin ← nested.originFor nested.source
                  let some inner := innerOrigin.application
                    | throwError "the nested field lost its originating application"
                  unless inner.path == #[``Prod.snd, ``Fin.val] &&
                      inner.dependencies.isEmpty && inner.contextDependencies.isEmpty &&
                      innerOrigin.access.map (·.value) == some point.value do
                    throwError "nested projection changed its original path or independent role"
                  checkSourceAddress nested #[``Prod.snd, ``Fin.val]
                  let hidden ← liftM (m := IO) do
                    try
                      discard <| graph.stage owners.identities innerOrigin (.portable "0".toUTF8)
                      pure false
                    catch error =>
                      pure (error.toString.endsWith "the value reference is outside the visible graph")
                  unless hidden do
                    throwError "projection provenance recovered an access operand outside its snapshot"
                  let (projected, numeric) ← liftM (m := IO) <|
                    projected.stage owners.identities innerOrigin (.portable "0".toUTF8)
                  discard <| nested.environment.checkResult projected nested.source numeric
                  liftM (m := IO) <| owners.close accessOwner.generation
                  liftM (m := IO) <| owners.close extraOwner.generation
                  unless ← liftM (m := BaseIO) (projected.isAvailable owners point) do
                    throwError "a delivered dependent field retained its accessor or unrelated owner"
                  liftM (m := IO) <| owners.close contextOwner.generation
                  if ← liftM (m := BaseIO) (projected.isAvailable owners point) then
                    throwError "a projected dependent field survived its original context owner"
                  unless ← liftM (m := BaseIO) (projected.isAvailable owners numeric) do
                    throwError "the delivered numeric field acquired an unrelated source owner"
  finally
    liftM (m := IO) <| owners.close contextOwner.generation
    liftM (m := IO) <| owners.close indexOwner.generation
    liftM (m := IO) <| owners.close accessOwner.generation
    liftM (m := IO) <| owners.close extraOwner.generation
