module

import CasCompiler.Read
import CasCompiler.SourceTestSupport
import CasCompiler.Parse
import LeanCategories.Catalogue.Semantics.Algebra.PolynomialPresentations
public meta import Lean.Elab.Command
meta import CasCompiler.Read
meta import CasCompiler.SourceTestSupport
meta import CasCompiler.Parse
meta import LeanCategories.Catalogue.Semantics.Algebra.PolynomialPresentations

open Lean Meta Elab Term CasCompiler CasCatalogue CasCompiler.SourceTest

-- The first two objects and generator applications come from the unchanged public F9
-- questions. The alias control checks source identity only: equal native carriers cannot
-- replace the actual named object. No comparison action or generator value is evaluated.
run_cmd Lean.Elab.Command.liftTermElabM do
  let original ← getEnv
  try
    let identities ← liftM (m := IO) CasRuntime.IdentitySupply.new
    let file ← SourceFile.parse "source-explicit-generators.cas"
      "let X := F9x\nlet Y := F9y\nlet Xalias := X\n\
       let GX := generator(X)\nlet GY := generator(Y)\nlet GA := generator(Xalias)\n"
    let mut session ← SourceSession.empty identities
    let expected := #[
      (`X, "obj.sets.f9_x", ``CasCatalogue.Algebra.PolynomialPresentations.firstGenerator),
      (`Y, "obj.sets.f9_y", ``CasCatalogue.Algebra.PolynomialPresentations.secondGenerator),
      (`Xalias, "obj.sets.f9_x", ``CasCatalogue.Algebra.PolynomialPresentations.firstGenerator)]
    for item in file.items, index in [:file.items.size] do
      let `(cas_item| $statement:cas_stmt) := item
        | throwError "the explicit generator control changed its parsed category"
      let .definition next value ← file.withContext (session.readStatement statement)
        | throwError "the explicit generator control is not a source definition"
      session := next
      if index < 3 then continue
      let some (name, objectId, declaration) := expected[index - 3]?
        | throwError "the generator control acquired an unexpected source statement"
      checkSelected value fun expression => do
        let scope ← get
        let some selected ← scope.context.bindings.findM? fun binding =>
            return (← binding.expression.fvarId!.getUserName) == name
          | liftM (m := TermElabM) <| throwError "the explicit generator lost its original source object"
        unless (← inferType expression) == selected.expression do
          liftM (m := TermElabM) <| throwError "the generator replaced its exact source object by another carrier"
        let some selection ← SourceReadM.selection? expression
          | liftM (m := TermElabM) <| throwError "the explicit generator lost its selected native binding"
        let some (.generator entry) := selection.reference
          | liftM (m := TermElabM) <| throwError "the explicit generator lost its selected catalogue reference"
        let #[originalEntry] := (← semanticState).objects.filter (·.id.raw == objectId)
          | liftM (m := TermElabM) <| throwError "the explicit generator lost its independently registered owner"
        unless entry.id.raw == objectId && entry.generator == some declaration &&
            (SelectedSourceReference.generator entry).exactlyMatches (.generator originalEntry) do
          liftM (m := TermElabM) <| throwError "the explicit generator changed its original registered declaration"
        checkOriginal #[expression] fun native => do
          unless native[0]!.containsConst (· == declaration) do
            throwError "the explicit generator changed its original registered declaration"
        let some ordinal := scope.context.bindings.findIdx? (·.id == selected.id)
          | liftM (m := TermElabM) <| throwError "the generator's source object is outside its complete telescope"
        unless (← contextDependencies scope.context.bindings (← inferType expression)).contains ordinal do
          liftM (m := TermElabM) <| throwError "the generator dropped its actual source-binding dependency"
  finally setEnv original
