module

import CasCompiler.Parse
public meta import Lean.Elab.Command
meta import CasCompiler.Parse

open Lean Elab Command CasCompiler CasCatalogue.Language

private def jsonFile (path : String) : CommandElabM Json := do
  let .ok document := Json.parse (← IO.FS.readFile path)
    | throwError "the retained source inventory is not valid JSON"
  return document

private def sourceIdentities (entries : Array Json) : CommandElabM (Std.HashSet String) := do
  let mut identities : Std.HashSet String := {}
  for entry in entries do
    let .ok path := entry.getObjValAs? String "source"
      | throwError "the retained input has no original source path"
    let text ← IO.FS.readFile path
    let source ← liftCoreM <| SourceFile.parse path text
    unless source.context.inputString == text && source.context.fileName == path do
      throwError "parsing changed the original source bytes or file identity"
    for item in source.items do
      unless item.raw.getPos?.isSome && item.raw.getTailPos?.isSome do
        throwError "a parsed original item lost its byte positions"
      match item with
      | `(cas_item| test $identity:ident $_:str : $_:cas_stmt) =>
        let identity := identity.getId.toString
        if identities.contains identity then throwError "a retained source identity occurs twice"
        identities := identities.insert identity
      | `(cas_item| $_:cas_stmt) => pure ()
      | _ => throwError "an original item changed its public syntax category"
  return identities

run_cmd do
  let fixture ← jsonFile "scripts/probes/fixed_question_export_inputs.json"
  let permanent ← jsonFile "CasAcceptance/Permanent/admitted.json"
  for (selection, inventory) in #[
      ("permanentSources", permanent), ("extensionSources", fixture)] do
    let .ok entries := fixture.getObjValAs? (Array Json) selection
      | throwError "the complete retained source selection is absent"
    let .ok expected := (inventory.getObjVal? "assertions").bind Json.getObj?
      | throwError "the original identity inventory is absent"
    let observed ← sourceIdentities entries
    unless observed.size == expected.size && expected.toList.all (observed.contains ·.1) do
      throwError "the source parser changed the original complete identity inventory"

run_cmd do
  let leading := "-- α\r\n\r\n"
  let binding := "let width := 3"
  let middle := "\r\nlet point((a, b)) := (a, b) in X → X\r\n\r\n"
  let question := "test parser.scope \"source\":\r\n  assert width = 3"
  let text := leading ++ binding ++ middle ++ question
  let source ← liftCoreM <| SourceFile.parse "source-positions.cas" text
  unless source.items.size == 3 && source.context.inputString == text do
    throwError "file parsing changed consecutive declarations or source line endings"
  let some first := source.items[0]? | throwError "the source binding is absent"
  let some last := source.items[2]? | throwError "the source question is absent"
  unless first.raw.getPos?.map (·.byteIdx) == some leading.utf8ByteSize &&
      last.raw.getPos?.map (·.byteIdx) ==
        some (leading ++ binding ++ middle).utf8ByteSize do
    throwError "Unicode or carriage returns changed original byte positions"
  let some position := last.raw.getPos? | throwError "the source question has no location"
  unless (source.context.fileMap.toPosition position).line == 6 do
    throwError "the source question lost its original line"
  let empty ← liftCoreM <| SourceFile.parse "empty.cas" "-- source comment\n"
  unless empty.items.isEmpty do throwError "a comment-only source acquired a statement"
  let rejected ← try
    discard <| liftCoreM <| SourceFile.parse "malformed.cas" "let width := 3\nassert ("
    pure false
  catch _ => pure true
  unless rejected do throwError "malformed trailing source was accepted as a complete file"

-- A mathematical rejection input remains intact past the syntax boundary.
run_cmd do
  let path := "tests/acceptance/proposals/independent-extension-reconstruction-20261024/" ++
    "completion/rx09-constant-one-rejection.cas"
  let text ← IO.FS.readFile path
  let source ← liftCoreM <| SourceFile.parse path text
  unless source.items.size == 5 && source.context.inputString == text do
    throwError "parsing changed the complete source-negative binding context"
  let some last := source.items[source.items.size - 1]?
    | throwError "the source-negative admission request is absent"
  let `(cas_item| let $name:ident := $_:cas_term) := last.raw
    | throwError "the source-negative admission request changed syntax"
  unless name.getId == `impossibleAdmission do
    throwError "the original source-negative admission identity changed"

-- Contextual command words keep their ordinary identifier uses, while complete
-- statement headers cannot become a preceding expression's juxtaposed operand.
run_cmd do
  for (text, count) in #[
      ("let f := x ↦ x in X → X\nlet g(x) := f(x) in X → X\n\
        let k := g ∘ f\nassert k(i) = i\n", 4),
      ("let context := 1\nlet assume := context\nlet inspect := assume\n\
        assert inspect = context\n", 4),
      ("let result := inspect assumptions\nassert result = result\n", 2),
      ("let result := x inspect\nassert result = result\n", 2),
      ("let result := x context\nassert result = result\n", 2),
      ("let result := x assume\nassert result = result\n", 2),
      ("let x := 1\ncontext do\nlet y := x\nend\ninspect assumptions\n", 3)] do
    let source ← liftCoreM <| SourceFile.parse "statement-boundaries.cas" text
    unless source.items.size == count && source.context.inputString == text do
      throwError "contextual commands changed original item boundaries: {text}"
  let text := "context do\nlet A ∈ Sets\nlet x ∈ A\nassume h : x = x\n\
    assert (x = x) using (proof(h))\ninspect assumptions\nend"
  let source ← liftCoreM <| SourceFile.parse "nested-statements.cas" text
  let #[item] := source.items
    | throwError "one source context was split into separate file items"
  let `(cas_item| $statement:cas_stmt) := item
    | throwError "the source context lost its statement node"
  unless statement.raw.isOfKind ``casContextBlock && statement.raw[2].getArgs.size == 5 do
    throwError "a contextual command was swallowed by an earlier nested expression"
  let children := statement.raw[2].getArgs
  let `(cas_item| $hypothesis:cas_stmt) := children[2]!
    | throwError "the original hypothesis lost its item node"
  let `(cas_item| $proved:cas_stmt) := children[3]!
    | throwError "the original supplied-proof assertion lost its item node"
  unless hypothesis.raw.isOfKind ``casHypothesis && proved.raw.isOfKind ``casProvedAssertion do
    throwError "the contextual statement boundary changed a hypothesis or supplied proof"
  for text in #["context do\nlet x := 1\n",
      "context do\nassume h x = x\nend", "inspect"] do
    let rejected ← try
      discard <| liftCoreM <| SourceFile.parse "malformed-context.cas" text
      pure false
    catch _ => pure true
    unless rejected do throwError "an incomplete contextual statement was accepted: {text}"
